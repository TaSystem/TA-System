import React, { useState, useEffect } from "react";
import Axios from "../../../config/Axios";
import SelectMajor from "../../../components/SelectMajor";
import ModalCoursesSA from "../../../components/ModalCoursesSA";
import ModalDetailNisit from "../../../components/ModalDetailNisit";
import Link from "next/link";
import { signIn, signOut, useSession } from "next-auth/client";
import { connect } from "react-redux";
import { getDetailNisit } from "../../../redux/actions/nisitAction";
import { useRouter } from "next/router";

function officerSASuccess(props) {
  const [users, setUsers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [nameModal, setNameModal] = useState([]);
  const [nisitValue, setNisitValue] = useState([]);
  const [session, loading] = useSession();
  const [search, setSearch] = useState(null);
  const [major, setMajor] = useState("All");
  const [yearNow, setYearNow] = useState([]);
  const [load, setLoad] = useState(false);
  const router = useRouter();

  useEffect(() => {
    async function getUsers() {
      setLoad(true);
      const response = await Axios.get(`/users/users-SA`);
      setUsers(response.data);
      setLoad(false);
    }
    async function getYear() {
      const response = await Axios.get("/setdate/getNow");
      setYearNow(response.data);
    }
    getYear();

    getUsers();
  }, []);

  useEffect(() => {
    if (session) {
      props.getDetailNisit(session.user.email);
    }
  }, [loading]);

  function Filter(users) {
    return users.filter((user) => {
      if (major == "All") {
        if (!search) {
          return user;
        } else if (user.name.toLowerCase().includes(search.toLowerCase())) {
          return user;
        } else if (user.lastname.toLowerCase().includes(search.toLowerCase())) {
          return user;
        } else if (
          user.idStudent.toLowerCase().includes(search.toLowerCase())
        ) {
          return user;
        }
      } else if (user.department == major) {
        if (!search) {
          return user;
        } else if (user.name.toLowerCase().includes(search.toLowerCase())) {
          return user;
        } else if (user.lastname.toLowerCase().includes(search.toLowerCase())) {
          return user;
        } else if (
          user.idStudent.toLowerCase().includes(search.toLowerCase())
        ) {
          return user;
        }
      }
    });
  }
  const showModalCourseSA = async (val) => {
    const response = await Axios.get(`/courses/courses-SA/${val.userID}`);
    setCourses(response.data);
    setNameModal({
      name: val.name,
      lastname: val.lastname,
      workHour: val.sumHour,
      year: val.year,
      term: val.term,
    });
  };

  const showModalNisit = (val) => {
    setNisitValue({
      CID: val.CID,
      email: val.email,
      name_email: val.name_email,
      name: val.name,
      lastname: val.lastname,
      idStudent: val.idStudent,
      lvl: val.lvl,
      department: val.department,
      roleTitle: val.roleTitle,
      tel: val.tel,
      nameBank: val.nameBank,
      idBank: val.idBank,
      fileCardStudent: val.fileCardStudent,
      fileBookBank: val.fileBookBank,
    });
  };

  const nisitCoursesSA = (id) => {
    return router.push(`/provost/officerSASuccess/${id}`);
  };

  if (typeof window !== "undefined" && loading) return null;

  if (!session) {
    //console.log("in that case");
    return (
      <div>
        <h2>You aren't signed in, please sign in first</h2>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>นิสิตSA(เจ้าหน้าที่)</h1>

      <div className="information">
        <h3>
          ปี{" "}
          {yearNow != null && yearNow.length != 0
            ? yearNow[0].year
            : "loading..."}{" "}
          เทอม{" "}
          {yearNow != null && yearNow.length != 0
            ? yearNow[0].term
            : "loading..."}
        </h3>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="รหัสวิชา/ชื่อวิชา/อาจารย์"
            onChange={(e) => setSearch(e.target.value)}
          />
          <SelectMajor
            onChange={(e) => {
              setMajor(e.target.value);
            }}
          />
        </div>
        จำนวนนิสิต:
        {users != null && users.length != 0 ? Filter(users).length : 0}
        <table
          className="table table-hover table-bordered"
          cellspacing="0"
          style={{ textAlign: "center" }}
        >
          <thead
            style={{
              position: "sticky",
              top: 0,
              background: "#7a0117",
              color: "#fff",
              fontWeight: "400",
            }}
          >
            <tr>
              <th rowSpan="2">ลำดับ</th>
              <th rowSpan="2">ชื่อ-สกุล</th>
              <th rowSpan="2">รหัสนิสิต</th>
              <th rowSpan="2">ระดับ</th>
              <th rowSpan="2">สาขาวิชา</th>
              <th rowSpan="2">อีเมลล์</th>
              <th rowSpan="2">เบอร์โทรศัพท์</th>

              <th rowSpan="2">จำนวนวิชาที่รับผิดชอบ</th>
            </tr>
          </thead>
          <tbody>
            {Filter(users).map((val, key) => {
              return (
                <tr>
                  <td>{key + 1}</td>
                  <td>
                    <Link href={`/provost/officerSASuccess/${val.UID}`}>
                      <a
                        
                        
                      >
                        {val.name} {val.lastname}
                      </a>
                    </Link>
                  </td>
                  <td>
                    <Link href="#">
                      <a
                        data-bs-toggle="modal"
                        data-bs-target="#ModalDetailNisit"
                        onClick={() => showModalNisit(val)}
                      >
                        {val.idStudent}
                      </a>
                    </Link>
                  </td>
                  <td>{val.lvl}</td>

                  <td>{val.department}</td>
                  <td>{val.email}</td>
                  <td>{val.tel}</td>
                  <td>
                    <Link href="#">
                      <a
                        data-bs-toggle="modal"
                        data-bs-target="#ModalCoursesSA"
                        onClick={() => showModalCourseSA(val)}
                      >
                        {val.count_courses}
                      </a>
                    </Link>
                  </td>
                </tr>
              );
            })}
            {load && <h2 style={{ color: "red" }}>กำลังโหลด...</h2>}
            {!load && users && !users.length && (
              <h2 style={{ color: "red" }}>ไม่มีนิสิตSA</h2>
            )}
          </tbody>
        </table>
        <ModalCoursesSA courses={courses} user={nameModal} />
        <ModalDetailNisit val={nisitValue} role={props.nisit.roleID} />
      </div>
    </div>
  );
}

const mapStateToProps = (state) => ({
  nisit: state.nisit.nisit,
});

const mapDispatchToProps = {
  getDetailNisit: getDetailNisit,
};

export default connect(mapStateToProps, mapDispatchToProps)(officerSASuccess);
